<?php
/**
 * Footer template for the Saad Shamsi portfolio theme.
 */
?>
<?php wp_footer(); ?>
</body>
</html>
