<?php
get_header();
?>
<style>
/* ==========================================================================
   SAAD SHAMSI — DevSecOps portfolio
   Converted into a WordPress theme page template.
   ========================================================================== */

.ss-site {
  --ss-bg: #0d0f12;
  --ss-bg-2: #101419;
  --ss-surface: rgba(255, 255, 255, 0.035);
  --ss-surface-2: rgba(255, 255, 255, 0.065);
  --ss-line: rgba(255, 255, 255, 0.09);
  --ss-line-hi: rgba(0, 242, 254, 0.42);
  --ss-text: #e9eef4;
  --ss-muted: #8b97a8;
  --ss-cyan: #00f2fe;
  --ss-green: #00ff88;

  --ss-font: 'Archivo', 'Bahnschrift', 'Segoe UI', system-ui, -apple-system, sans-serif;
  --ss-mono: 'IBM Plex Mono', 'Cascadia Mono', ui-monospace, Consolas, monospace;

  --ss-ease: cubic-bezier(0.16, 1, 0.3, 1);
  --ss-gutter: clamp(20px, 5vw, 64px);
  --ss-max: 1200px;

  background: var(--ss-bg);
  color: var(--ss-text);
  font-family: var(--ss-font);
  font-size: 16px;
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
  position: relative;
}

.ss-site *, .ss-site *::before, .ss-site *::after { box-sizing: border-box; }
.ss-site h1, .ss-site h2, .ss-site h3, .ss-site h4, .ss-site p { margin: 0; }
.ss-site ul, .ss-site ol { margin: 0; padding: 0; list-style: none; }
.ss-site img { max-width: 100%; display: block; }
.ss-site a { color: inherit; text-decoration: none; }
.ss-site button { font: inherit; color: inherit; background: none; border: 0; cursor: pointer; }
.ss-site :focus-visible { outline: 2px solid var(--ss-cyan); outline-offset: 3px; border-radius: 2px; }
.ss-site ::selection { background: rgba(0, 242, 254, 0.28); color: #fff; }

.ss-wrap { width: 100%; max-width: var(--ss-max); margin-inline: auto; padding-inline: var(--ss-gutter); }
.ss-h2 { font-size: clamp(1.9rem, 3.4vw, 2.85rem); line-height: 1.08; letter-spacing: -0.025em; font-weight: 600; text-wrap: balance; }
.ss-lead { color: var(--ss-muted); font-size: clamp(0.98rem, 1.2vw, 1.075rem); line-height: 1.72; max-width: 56ch; }
.ss-mono { font-family: var(--ss-mono); font-size: 0.75rem; letter-spacing: 0.02em; }
.ss-section { position: relative; padding-block: clamp(72px, 10vw, 132px); }
.ss-section + .ss-section { padding-top: clamp(48px, 7vw, 88px); }
.ss-section-head { display: flex; flex-wrap: wrap; align-items: flex-end; justify-content: space-between; gap: 20px 48px; margin-bottom: clamp(36px, 5vw, 64px); padding-bottom: 22px; border-bottom: 1px solid var(--ss-line); }
.ss-section-head .ss-lead { max-width: 44ch; }

.ss-progress { position: fixed; inset: 0 auto auto 0; width: 100%; height: 2px; z-index: 9999; background: linear-gradient(90deg, var(--ss-cyan), var(--ss-green)); transform: scaleX(0); transform-origin: 0 50%; will-change: transform; pointer-events: none; }
.ss-nav { position: fixed; inset: 0 0 auto 0; z-index: 900; display: flex; align-items: center; justify-content: space-between; gap: 24px; padding: 18px var(--ss-gutter); border-bottom: 1px solid transparent; transition: background 0.45s var(--ss-ease), border-color 0.45s var(--ss-ease), padding 0.45s var(--ss-ease), backdrop-filter 0.45s var(--ss-ease); }
.ss-nav.is-scrolled { padding-block: 12px; background: rgba(13, 15, 18, 0.72); border-bottom-color: var(--ss-line); backdrop-filter: blur(14px) saturate(140%); }
.ss-brand { display: inline-flex; align-items: center; gap: 10px; font-weight: 600; letter-spacing: -0.01em; font-size: 0.95rem; }
.ss-brand__mark { width: 26px; height: 26px; display: grid; place-items: center; border: 1px solid var(--ss-line-hi); border-radius: 3px; font-family: var(--ss-mono); font-size: 0.68rem; color: var(--ss-cyan); box-shadow: inset 0 0 14px rgba(0, 242, 254, 0.16); }
.ss-brand small { font-family: var(--ss-mono); font-size: 0.66rem; font-weight: 400; color: var(--ss-muted); letter-spacing: 0.02em; }
.ss-nav__links { display: flex; align-items: center; gap: 30px; }
.ss-nav__links a { position: relative; font-size: 0.875rem; color: var(--ss-muted); transition: color 0.3s var(--ss-ease); }
.ss-nav__links a::after { content: ""; position: absolute; left: 0; bottom: -6px; width: 100%; height: 1px; background: var(--ss-cyan); transform: scaleX(0); transform-origin: 0 50%; transition: transform 0.35s var(--ss-ease); }
.ss-nav__links a:hover { color: var(--ss-text); }
.ss-nav__links a:hover::after { transform: scaleX(1); }
.ss-nav__cta { display: flex; align-items: center; gap: 14px; }
.ss-avail { display: inline-flex; align-items: center; gap: 8px; font-family: var(--ss-mono); font-size: 0.7rem; color: var(--ss-muted); white-space: nowrap; }
.ss-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--ss-green); box-shadow: 0 0 0 0 rgba(0, 255, 136, 0.6); animation: ss-pulse 2.6s ease-out infinite; }
@keyframes ss-pulse { 0% { box-shadow: 0 0 0 0 rgba(0, 255, 136, 0.55); } 70% { box-shadow: 0 0 0 7px rgba(0, 255, 136, 0); } 100% { box-shadow: 0 0 0 0 rgba(0, 255, 136, 0); } }
.ss-burger { display: none; width: 40px; height: 40px; border: 1px solid var(--ss-line); border-radius: 4px; position: relative; }
.ss-burger span { position: absolute; left: 11px; width: 16px; height: 1.5px; background: var(--ss-text); transition: transform 0.35s var(--ss-ease), opacity 0.25s; }
.ss-burger span:first-child { top: 16px; }
.ss-burger span:last-child { top: 22px; }
.ss-burger[aria-expanded="true"] span:first-child { transform: translateY(3px) rotate(45deg); }
.ss-burger[aria-expanded="true"] span:last-child { transform: translateY(-3px) rotate(-45deg); }
.ss-mobile-menu { position: fixed; inset: 0; z-index: 890; display: grid; align-content: center; gap: 6px; padding: 0 var(--ss-gutter); background: rgba(9, 11, 14, 0.96); backdrop-filter: blur(10px); opacity: 0; visibility: hidden; transition: opacity 0.4s var(--ss-ease), visibility 0.4s; }
.ss-mobile-menu.is-open { opacity: 1; visibility: visible; }
.ss-mobile-menu a { font-size: clamp(1.6rem, 8vw, 2.2rem); font-weight: 600; letter-spacing: -0.02em; padding: 12px 0; border-bottom: 1px solid var(--ss-line); color: var(--ss-text); }
.ss-mobile-menu a span { font-family: var(--ss-mono); font-size: 0.7rem; color: var(--ss-muted); margin-right: 14px; vertical-align: super; }

.ss-btn { position: relative; display: inline-flex; align-items: center; justify-content: center; gap: 10px; min-height: 50px; padding: 0 26px; border-radius: 999px; font-size: 0.92rem; font-weight: 600; letter-spacing: -0.005em; color: #06121a; background: linear-gradient(102deg, #00f2fe 0%, #46f7ff 52%, #00ff88 135%); box-shadow: 0 0 0 1px rgba(0, 242, 254, 0.35), 0 10px 34px -12px rgba(0, 242, 254, 0.65); overflow: hidden; transition: transform 0.4s var(--ss-ease), box-shadow 0.4s var(--ss-ease); }
.ss-btn::after { content: ""; position: absolute; inset: 0; background: linear-gradient(100deg, transparent 20%, rgba(255, 255, 255, 0.55) 48%, transparent 72%); transform: translateX(-120%); transition: transform 0.75s var(--ss-ease); }
.ss-btn:hover { transform: translateY(-2px); box-shadow: 0 0 0 1px rgba(0, 242, 254, 0.5), 0 18px 44px -14px rgba(0, 242, 254, 0.8); }
.ss-btn:hover::after { transform: translateX(120%); }
.ss-btn:active { transform: translateY(0); }
.ss-btn--ghost { --btn-fg: var(--ss-text); background: transparent; border: 1px solid var(--ss-line); box-shadow: none; transition: border-color 0.35s, background 0.35s, transform 0.4s var(--ss-ease), color 0.35s; }
.ss-btn--ghost::after { display: none; }
.ss-btn--ghost:hover { border-color: var(--ss-line-hi); background: rgba(0, 242, 254, 0.06); color: #fff; box-shadow: 0 0 24px -8px rgba(0, 242, 254, 0.45); transform: translateY(-2px); }
.ss-btn svg { width: 15px; height: 15px; flex: none; }

.ss-hero { position: relative; min-height: 100svh; display: flex; align-items: center; padding: 132px 0 clamp(48px, 6vw, 76px); overflow: hidden; isolation: isolate; }
.ss-hero__bg { position: absolute; inset: 0; z-index: -2; background: radial-gradient(1100px 620px at 78% 8%, rgba(0, 242, 254, 0.09), transparent 62%), radial-gradient(820px 520px at 8% 92%, rgba(0, 255, 136, 0.05), transparent 65%), linear-gradient(180deg, #0b0d10 0%, var(--ss-bg) 55%, #0a0c0f 100%); }
.ss-hero__grid { position: absolute; inset: -10% -20% 0; z-index: -2; background-image: linear-gradient(rgba(255, 255, 255, 0.045) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.045) 1px, transparent 1px); background-size: 64px 64px; -webkit-mask-image: radial-gradient(620px 520px at 72% 34%, #000 0%, transparent 78%); mask-image: radial-gradient(620px 520px at 72% 34%, #000 0%, transparent 78%); opacity: 0.55; animation: ss-drift 34s linear infinite; }
@keyframes ss-drift { from { background-position: 0 0, 0 0; } to { background-position: 64px 64px, 64px 64px; } }
.ss-particles { position: absolute; inset: 0; z-index: -1; width: 100%; height: 100%; opacity: 0.85; pointer-events: none; }
.ss-hero__grid-c { display: grid; grid-template-columns: minmax(0, 1.08fr) minmax(0, 0.92fr); align-items: center; gap: clamp(28px, 5vw, 72px); width: 100%; }
.ss-hero__copy { max-width: 660px; }
.ss-hero__status { display: inline-flex; align-items: center; gap: 10px; padding: 7px 14px 7px 11px; border: 1px solid var(--ss-line); border-radius: 999px; background: rgba(255, 255, 255, 0.03); font-family: var(--ss-mono); font-size: 0.71rem; color: var(--ss-muted); margin-bottom: clamp(24px, 3vw, 34px); }
.ss-hero__status b { color: var(--ss-green); font-weight: 500; }
.ss-title { font-size: clamp(2.45rem, 5.6vw, 4.75rem); line-height: 0.99; letter-spacing: -0.038em; font-weight: 600; color: #f2f6fa; text-wrap: balance; }
.ss-title .amp { color: var(--ss-cyan); font-weight: 400; }
.ss-line { display: block; overflow: hidden; padding-bottom: 0.06em; }
.ss-line > span { display: block; transform: translateY(115%); transition: transform 1.05s var(--ss-ease); }
.ss-site.is-loaded .ss-line > span { transform: translateY(0); }
.ss-line:nth-child(2) > span { transition-delay: 0.09s; }
.ss-line:nth-child(3) > span { transition-delay: 0.18s; }
.ss-hero__sub { margin-top: 22px; max-width: 46ch; color: var(--ss-muted); font-size: clamp(0.98rem, 1.15vw, 1.06rem); line-height: 1.7; }
.ss-hero__actions { display: flex; flex-wrap: wrap; gap: 14px; margin-top: clamp(28px, 3.4vw, 40px); }
.ss-hero__stack { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 18px; margin-top: clamp(30px, 4vw, 46px); padding-top: 20px; border-top: 1px solid var(--ss-line); font-family: var(--ss-mono); font-size: 0.71rem; color: #6d7987; }
.ss-hero__stack span { transition: color 0.3s; }
.ss-hero__stack span:hover { color: var(--ss-cyan); }

.ss-portrait { position: relative; justify-self: end; width: 100%; max-width: 460px; aspect-ratio: 1 / 1; display: grid; place-items: center; isolation: isolate; }
.ss-portrait::before { content: ""; position: absolute; inset: -12%; z-index: -2; background: conic-gradient(from 0deg, rgba(0, 242, 254, 0.18), transparent 25%, rgba(0, 255, 136, 0.12), transparent 60%, rgba(0, 242, 254, 0.18)); filter: blur(24px); opacity: 0.9; animation: ss-spin 24s linear infinite; }
@keyframes ss-spin { to { transform: rotate(1turn); } }

.ss-logo-card {
  position: relative;
  width: min(84%, 360px);
  aspect-ratio: 1 / 1;
  display: grid;
  place-items: center;
  border-radius: 32px;
  border: 1px solid var(--ss-line);
  background: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.015));
  box-shadow: inset 0 0 30px rgba(255,255,255,0.02), 0 10px 28px rgba(0,0,0,0.24);
  overflow: hidden;
}
.ss-logo-card::before,
.ss-logo-card::after {
  content: "";
  position: absolute;
  inset: 12%;
  border: 1px solid rgba(0, 242, 254, 0.18);
  border-radius: 24px;
}
.ss-logo-card::after {
  inset: 20% 18% 18% 18%;
  border-color: rgba(0, 255, 136, 0.18);
}

.ss-logo-core {
  position: relative;
  width: 60%;
  aspect-ratio: 1;
  display: grid;
  place-items: center;
  border-radius: 50%;
  background: radial-gradient(circle at 30% 25%, rgba(0,242,254,0.18), rgba(0,242,254,0.03) 35%, rgba(0,0,0,0.08) 70%);
  border: 1px solid rgba(0, 242, 254, 0.4);
  box-shadow: inset 0 0 22px rgba(0,242,254,0.12), 0 0 35px rgba(0,242,254,0.12);
}
.ss-logo-core::before,
.ss-logo-core::after {
  content: "";
  position: absolute;
  border-radius: 50%;
  inset: 10%;
  border: 1px solid rgba(255,255,255,0.12);
}
.ss-logo-core::after {
  inset: 20%;
  border-color: rgba(0, 255, 136, 0.3);
}

.ss-logo-mark {
  position: relative;
  z-index: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 72px;
  height: 72px;
  border-radius: 18px;
  border: 1px solid rgba(0, 242, 254, 0.54);
  background: rgba(9, 12, 16, 0.72);
  color: var(--ss-cyan);
  font-family: var(--ss-mono);
  font-size: 1.34rem;
  font-weight: 600;
  letter-spacing: -0.04em;
  box-shadow: inset 0 0 20px rgba(0,242,254,0.08);
}

.ss-logo-meta {
  position: absolute;
  left: 20px;
  right: 20px;
  bottom: 18px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  font-family: var(--ss-mono);
  color: var(--ss-muted);
  font-size: 0.62rem;
  letter-spacing: 0.18em;
  text-transform: uppercase;
}
.ss-logo-meta strong {
  color: var(--ss-text);
  letter-spacing: 0.22em;
}
.ss-logo-meta span:last-child {
  color: var(--ss-green);
}

.ss-portrait__bracket { position: absolute; width: 26px; height: 26px; border: 1px solid var(--ss-line-hi); opacity: 0.75; }
.ss-portrait__bracket:nth-of-type(1) { top: 6%; left: 2%; border-right: 0; border-bottom: 0; }
.ss-portrait__bracket:nth-of-type(2) { top: 6%; right: 2%; border-left: 0; border-bottom: 0; }
.ss-portrait__bracket:nth-of-type(3) { bottom: 18%; left: 2%; border-right: 0; border-top: 0; }
.ss-portrait__bracket:nth-of-type(4) { bottom: 18%; right: 2%; border-left: 0; border-top: 0; }

.ss-metrics { position: relative; border-block: 1px solid var(--ss-line); background: linear-gradient(180deg, rgba(255, 255, 255, 0.022), transparent 60%), var(--ss-bg-2); }
.ss-metrics__grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); }
.ss-metric { padding: clamp(26px, 3.4vw, 42px) clamp(16px, 2.4vw, 34px); border-left: 1px solid var(--ss-line); position: relative; overflow: hidden; }
.ss-metric:first-child { border-left: 0; }
.ss-metric::before { content: ""; position: absolute; inset: auto 0 0 0; height: 1px; background: linear-gradient(90deg, var(--ss-cyan), var(--ss-green)); transform: scaleX(0); transform-origin: 0 50%; transition: transform 0.9s var(--ss-ease); }
.ss-metrics.is-in .ss-metric::before { transform: scaleX(1); }
.ss-metric:nth-child(2)::before { transition-delay: 0.1s; }
.ss-metric:nth-child(3)::before { transition-delay: 0.2s; }
.ss-metric:nth-child(4)::before { transition-delay: 0.3s; }
.ss-metric__val { font-family: var(--ss-mono); font-size: clamp(1.85rem, 3.4vw, 2.85rem); font-weight: 500; line-height: 1; letter-spacing: -0.04em; font-variant-numeric: tabular-nums; background: linear-gradient(180deg, #ffffff 8%, #9fb3c6 92%); -webkit-background-clip: text; background-clip: text; color: transparent; }
.ss-metric__label { margin-top: 12px; font-size: 0.79rem; line-height: 1.5; color: var(--ss-muted); max-width: 22ch; }

.ss-cards { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: clamp(14px, 1.6vw, 22px); }
.ss-card { position: relative; display: flex; flex-direction: column; gap: 16px; padding: clamp(24px, 2.8vw, 34px); border: 1px solid var(--ss-line); border-radius: 4px; background: linear-gradient(170deg, var(--ss-surface-2), rgba(255, 255, 255, 0.012)); backdrop-filter: blur(12px); overflow: hidden; transform: perspective(900px) rotateX(var(--rx)) rotateY(var(--ry)); transform-style: preserve-3d; transition: transform 0.45s var(--ss-ease), border-color 0.45s var(--ss-ease), box-shadow 0.45s var(--ss-ease); }
.ss-card::before { content: ""; position: absolute; inset: 0 0 auto 0; height: 1.5px; background: linear-gradient(90deg, var(--ss-cyan), var(--ss-green)); transform: scaleX(0); transform-origin: 0 50%; transition: transform 0.6s var(--ss-ease); }
.ss-card::after { content: ""; position: absolute; inset: 0; border-radius: inherit; background: radial-gradient(340px circle at var(--mx) var(--my), rgba(0, 242, 254, 0.11), transparent 62%); opacity: 0; transition: opacity 0.45s var(--ss-ease); pointer-events: none; }
.ss-card:hover { border-color: rgba(0, 242, 254, 0.24); box-shadow: 0 22px 60px -34px rgba(0, 242, 254, 0.75); }
.ss-card:hover::before { transform: scaleX(1); }
.ss-card:hover::after { opacity: 1; }
.ss-card__icon { width: 42px; height: 42px; display: grid; place-items: center; border: 1px solid var(--ss-line); border-radius: 3px; color: var(--ss-cyan); background: rgba(0, 242, 254, 0.05); transition: border-color 0.4s, box-shadow 0.4s, color 0.4s; }
.ss-card:hover .ss-card__icon { border-color: rgba(0, 242, 254, 0.4); box-shadow: inset 0 0 20px -6px rgba(0, 242, 254, 0.55); }
.ss-card__icon svg { width: 21px; height: 21px; }
.ss-card__title { font-size: 1.16rem; font-weight: 600; letter-spacing: -0.018em; line-height: 1.3; }
.ss-card__desc { font-size: 0.885rem; line-height: 1.65; color: var(--ss-muted); }
.ss-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-top: auto; padding-top: 16px; border-top: 1px dashed rgba(255, 255, 255, 0.08); }
.ss-chip { font-family: var(--ss-mono); font-size: 0.685rem; line-height: 1; padding: 7px 9px; border: 1px solid rgba(255, 255, 255, 0.075); border-radius: 3px; color: #98a6b6; background: rgba(255, 255, 255, 0.018); transition: color 0.3s, border-color 0.3s, background 0.3s, transform 0.3s var(--ss-ease); }
.ss-chip:hover { color: var(--ss-cyan); border-color: rgba(0, 242, 254, 0.45); background: rgba(0, 242, 254, 0.07); transform: translateY(-1px); }

.ss-timeline { position: relative; }
.ss-timeline__rail { position: absolute; left: 168px; top: 6px; bottom: 6px; width: 1px; background: var(--ss-line); }
.ss-timeline__fill { position: absolute; inset: 0; background: linear-gradient(180deg, var(--ss-cyan), var(--ss-green)); transform: scaleY(0); transform-origin: 50% 0; will-change: transform; box-shadow: 0 0 12px rgba(0, 242, 254, 0.5); }
.ss-job { display: grid; grid-template-columns: 136px 64px minmax(0, 1fr); align-items: start; position: relative; }
.ss-job__when { padding-top: 4px; font-family: var(--ss-mono); font-size: 0.72rem; line-height: 1.55; color: #6f7c8b; text-align: right; transition: color 0.4s var(--ss-ease); }
.ss-job__when b { display: block; color: var(--ss-muted); font-weight: 500; }
.ss-job.is-open .ss-job__when b { color: var(--ss-cyan); }
.ss-job__node { position: relative; height: 100%; display: flex; justify-content: center; }
.ss-job__node::before { content: ""; position: absolute; top: 7px; width: 9px; height: 9px; border-radius: 50%; background: var(--ss-bg); border: 1px solid #4a5563; transition: border-color 0.4s, background 0.4s, box-shadow 0.4s; }
.ss-job.is-open .ss-job__node::before, .ss-job--now .ss-job__node::before { border-color: var(--ss-green); background: var(--ss-green); box-shadow: 0 0 0 4px rgba(0, 255, 136, 0.12), 0 0 16px rgba(0, 255, 136, 0.7); }
.ss-job__body { padding: 0 0 clamp(20px, 2.4vw, 30px) 26px; }
.ss-job__row { display: flex; align-items: flex-start; justify-content: space-between; gap: 18px; width: 100%; text-align: left; padding: 0 0 14px; }
.ss-job__role { font-size: clamp(1.06rem, 1.5vw, 1.24rem); font-weight: 600; letter-spacing: -0.018em; line-height: 1.3; color: var(--ss-text); transition: color 0.35s; }
.ss-job__row:hover .ss-job__role { color: #fff; }
.ss-job__co { display: block; margin-top: 5px; font-family: var(--ss-mono); font-size: 0.73rem; color: var(--ss-muted); }
.ss-job__co i { font-style: normal; color: #5d6875; }
.ss-job__sign { flex: none; width: 26px; height: 26px; margin-top: 2px; position: relative; border: 1px solid var(--ss-line); border-radius: 50%; transition: border-color 0.35s, background 0.35s; }
.ss-job__sign::before, .ss-job__sign::after { content: ""; position: absolute; inset: 50% 7px auto; height: 1px; background: var(--ss-muted); transition: transform 0.35s var(--ss-ease), background 0.35s; }
.ss-job__sign::after { transform: rotate(90deg); }
.ss-job.is-open .ss-job__sign { border-color: rgba(0, 242, 254, 0.45); background: rgba(0, 242, 254, 0.07); }
.ss-job.is-open .ss-job__sign::after { transform: rotate(0deg); }
.ss-job.is-open .ss-job__sign::before, .ss-job.is-open .ss-job__sign::after { background: var(--ss-cyan); }
.ss-job__panel { display: grid; grid-template-rows: 0fr; transition: grid-template-rows 0.6s var(--ss-ease); }
.ss-job.is-open .ss-job__panel { grid-template-rows: 1fr; }
.ss-job__panel > div { overflow: hidden; }
.ss-job__list { display: grid; gap: 9px; padding-bottom: 4px; opacity: 0; transform: translateY(-4px); transition: opacity 0.45s var(--ss-ease) 0.1s, transform 0.45s var(--ss-ease) 0.1s; }
.ss-job.is-open .ss-job__list { opacity: 1; transform: none; }
.ss-job__list li { position: relative; padding-left: 18px; font-size: 0.9rem; line-height: 1.65; color: #a9b5c3; }
.ss-job__list li::before { content: ""; position: absolute; left: 0; top: 0.62em; width: 6px; height: 1px; background: var(--ss-cyan); opacity: 0.6; }
.ss-job__tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 14px; }

.ss-creds { display: grid; grid-template-columns: minmax(0, 1.05fr) minmax(0, 0.95fr); gap: clamp(32px, 5vw, 76px); }
.ss-subhead { font-size: 0.78rem; font-family: var(--ss-mono); color: var(--ss-muted); margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid var(--ss-line); display: flex; justify-content: space-between; gap: 16px; }
.ss-edu { display: grid; gap: 2px; }
.ss-edu li { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 6px 24px; align-items: baseline; padding: 18px 0; border-bottom: 1px solid var(--ss-line); transition: padding-left 0.45s var(--ss-ease), border-color 0.45s; }
.ss-edu li:first-child { border-top: 1px solid var(--ss-line); }
.ss-edu li:hover { padding-left: 10px; border-color: rgba(0, 242, 254, 0.25); }
.ss-edu__deg { font-size: 1.02rem; font-weight: 600; letter-spacing: -0.012em; }
.ss-edu__school { grid-column: 1; font-size: 0.84rem; color: var(--ss-muted); }
.ss-edu__yr { grid-column: 2; grid-row: 1 / span 2; font-family: var(--ss-mono); font-size: 0.72rem; color: #6f7c8b; white-space: nowrap; }
.ss-edu__yr.now { color: var(--ss-green); }
.ss-certs { display: grid; grid-template-columns: 1fr 1fr; gap: 1px; background: var(--ss-line); border: 1px solid var(--ss-line); }
.ss-certs li { background: var(--ss-bg); padding: 14px 15px; display: grid; gap: 3px; transition: background 0.35s; position: relative; }
.ss-certs li::before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 1px; background: var(--ss-cyan); transform: scaleY(0); transform-origin: 50% 0; transition: transform 0.4s var(--ss-ease); }
.ss-certs li:hover { background: rgba(0, 242, 254, 0.035); }
.ss-certs li:hover::before { transform: scaleY(1); }
.ss-certs b { font-size: 0.855rem; font-weight: 500; line-height: 1.4; letter-spacing: -0.008em; }
.ss-certs span { font-family: var(--ss-mono); font-size: 0.66rem; color: #6f7c8b; }

.ss-contact { position: relative; overflow: hidden; border-top: 1px solid var(--ss-line); background: radial-gradient(900px 460px at 12% 0%, rgba(0, 242, 254, 0.075), transparent 62%), linear-gradient(180deg, #0b0d10, #08090b); }
.ss-contact__grid { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: clamp(40px, 6vw, 90px); align-items: start; }
.ss-contact__h { font-size: clamp(2rem, 4vw, 3.1rem); line-height: 1.08; letter-spacing: -0.035em; font-weight: 600; text-wrap: balance; }
.ss-contact__h em { font-style: normal; background: linear-gradient(96deg, var(--ss-cyan), var(--ss-green)); -webkit-background-clip: text; background-clip: text; color: transparent; }
.ss-contact__p { margin-top: 22px; color: var(--ss-muted); max-width: 40ch; line-height: 1.7; }
.ss-links { margin-top: clamp(28px, 3.4vw, 38px); border-top: 1px solid var(--ss-line); }
.ss-link { display: flex; align-items: center; gap: 16px; padding: 17px 2px; border-bottom: 1px solid var(--ss-line); transition: padding-left 0.45s var(--ss-ease), color 0.35s; }
.ss-link:hover { padding-left: 10px; color: #fff; }
.ss-link__k { font-family: var(--ss-mono); font-size: 0.7rem; color: #6f7c8b; width: 76px; flex: none; }
.ss-link__v { font-size: 0.94rem; letter-spacing: -0.008em; flex: 1 1 auto; }
.ss-link svg { width: 14px; height: 14px; flex: none; margin-left: auto; color: var(--ss-cyan); opacity: 0.75; transition: transform 0.4s var(--ss-ease), opacity 0.4s; }
.ss-link:hover svg { transform: translate(2px, -2px); opacity: 1; }
.ss-form { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; padding: clamp(22px, 3vw, 32px); border: 1px solid var(--ss-line); border-radius: 6px; background: linear-gradient(165deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.012)); backdrop-filter: blur(14px); }
.ss-field { position: relative; }
.ss-field--full { grid-column: 1 / -1; }
.ss-field input, .ss-field textarea { width: 100%; padding: 22px 14px 10px; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 4px; background: rgba(0, 0, 0, 0.28); color: var(--ss-text); font-family: inherit; font-size: 0.92rem; line-height: 1.5; transition: border-color 0.35s, box-shadow 0.35s, background 0.35s; outline: none; appearance: none; }
.ss-field textarea { resize: vertical; min-height: 120px; }
.ss-field label { position: absolute; left: 15px; top: 15px; font-size: 0.9rem; color: #7d8998; pointer-events: none; transform-origin: 0 0; transition: transform 0.3s var(--ss-ease), color 0.3s, font-size 0.3s; }
.ss-field input:focus, .ss-field textarea:focus { border-color: rgba(0, 242, 254, 0.55); box-shadow: 0 0 0 3px rgba(0, 242, 254, 0.1), inset 0 0 30px -18px rgba(0, 242, 254, 0.8); background: rgba(0, 242, 254, 0.025); }
.ss-field input:focus + label, .ss-field textarea:focus + label, .ss-field input:not(:placeholder-shown) + label, .ss-field textarea:not(:placeholder-shown) + label { transform: translateY(-9px) scale(0.76); color: var(--ss-cyan); }
.ss-form__foot { grid-column: 1 / -1; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 14px; margin-top: 4px; }
.ss-form__note { font-family: var(--ss-mono); font-size: 0.68rem; color: #66717f; max-width: 30ch; }
.ss-form__msg { grid-column: 1 / -1; font-family: var(--ss-mono); font-size: 0.75rem; color: var(--ss-green); opacity: 0; transform: translateY(-4px); transition: opacity 0.4s, transform 0.4s; }
.ss-form.is-sent .ss-form__msg { opacity: 1; transform: none; }
.ss-footer { border-top: 1px solid var(--ss-line); padding: 26px 0; background: #08090b; }
.ss-footer__c { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px 24px; font-family: var(--ss-mono); font-size: 0.7rem; color: #626d7a; }
.ss-footer__c a { color: #8b97a8; transition: color 0.3s; }
.ss-footer__c a:hover { color: var(--ss-cyan); }

.ss-site [data-reveal] { opacity: 0; transform: translateY(20px); transition: opacity 0.85s var(--ss-ease), transform 0.85s var(--ss-ease); transition-delay: var(--d, 0ms); }
.ss-site [data-reveal="fade"] { transform: none; }
.ss-site [data-reveal="scale"] { transform: scale(0.965); }
.ss-site [data-reveal].is-in { opacity: 1; transform: none; }
.ss-site.is-loaded .ss-hero [data-hero] { opacity: 1; transform: none; transition: opacity 0.9s var(--ss-ease) var(--d, 0.35s), transform 0.9s var(--ss-ease) var(--d, 0.35s); }
.ss-site .ss-hero [data-hero] { opacity: 0; transform: translateY(14px); transition: none; }

@media (prefers-reduced-motion: reduce) {
  .ss-site *, .ss-site *::before, .ss-site *::after { animation-duration: 0.001ms !important; animation-iteration-count: 1 !important; transition-duration: 0.001ms !important; scroll-behavior: auto !important; }
  .ss-site [data-reveal], .ss-site .ss-hero [data-hero] { opacity: 1 !important; transform: none !important; }
  .ss-line > span { transform: none !important; }
  .ss-portrait__img { clip-path: none !important; }
  .ss-particles, .ss-portrait__scan, .ss-hero__grid { display: none; }
  .ss-card { transform: none !important; }
}

@media (max-width: 1080px) {
  .ss-hero { min-height: auto; padding-top: 118px; }
  .ss-hero__grid-c { grid-template-columns: minmax(0, 1fr) minmax(0, 0.78fr); }
  .ss-portrait { max-width: 380px; }
  .ss-creds { grid-template-columns: 1fr; }
  .ss-timeline__rail { left: 128px; }
  .ss-job { grid-template-columns: 96px 56px minmax(0, 1fr); }
  .ss-job__when { font-size: 0.68rem; }
}

@media (max-width: 900px) {
  .ss-nav { padding-block: 14px; }
  .ss-nav__links { display: none; }
  .ss-burger { display: block; }
  .ss-avail { display: none; }
  .ss-nav__cta .ss-btn { min-height: 42px; padding: 0 18px; font-size: 0.84rem; }
  .ss-hero { padding-top: 100px; }
  .ss-hero__grid-c { grid-template-columns: 1fr; gap: 30px; }
  .ss-title { font-size: clamp(2.05rem, 8.2vw, 3rem); line-height: 1.02; }
  .ss-hero__copy { max-width: none; }
  .ss-portrait { justify-self: start; order: 2; max-width: min(340px, 74vw); aspect-ratio: 1 / 1; margin-top: -6px; }
  .ss-portrait__img { object-position: 50% 22%; }
  .ss-portrait__tag { bottom: 2%; right: 4%; }
  .ss-hero__copy { order: 1; }
  .ss-hero__actions { width: 100%; }
  .ss-hero__actions .ss-btn { flex: 1 1 auto; }
  .ss-hero__stack { margin-top: 26px; padding-top: 16px; }
  .ss-cards { grid-template-columns: 1fr; }
  .ss-card { transform: none !important; }
  .ss-metrics__grid { grid-template-columns: 1fr 1fr; }
  .ss-metric:nth-child(odd) { border-left: 0; }
  .ss-metric:nth-child(-n + 2) { border-bottom: 1px solid var(--ss-line); }
  .ss-metric__label { max-width: 26ch; }
  .ss-contact__grid { grid-template-columns: 1fr; }
  .ss-form { padding: 20px; }
}

@media (max-width: 680px) {
  .ss-site { font-size: 15.5px; }
  .ss-section-head { margin-bottom: 30px; }
  .ss-title { font-size: clamp(2.15rem, 9.4vw, 2.9rem); letter-spacing: -0.03em; }
  .ss-hero { padding-top: 104px; }
  .ss-hero__status { font-size: 0.65rem; padding: 6px 12px 6px 9px; }
  .ss-hero__stack { gap: 6px 14px; font-size: 0.66rem; }
  .ss-timeline__rail { left: 4px; }
  .ss-job { grid-template-columns: 22px minmax(0, 1fr); }
  .ss-job__when { grid-column: 2; text-align: left; padding: 0 0 6px 18px; display: flex; gap: 8px; align-items: baseline; }
  .ss-job__when b { display: inline; }
  .ss-job__when span { display: none; }
  .ss-job__node { grid-column: 1; grid-row: 1 / span 2; }
  .ss-job__node::before { top: 9px; width: 7px; height: 7px; }
  .ss-job__body { grid-column: 2; padding-left: 18px; }
  .ss-job__row { padding-right: 0; }
  .ss-job__role { font-size: 1rem; }
  .ss-certs { grid-template-columns: 1fr; }
  .ss-form { grid-template-columns: 1fr; }
  .ss-field--full { grid-column: auto; }
  .ss-form__foot { flex-direction: column; align-items: stretch; }
  .ss-form__foot .ss-btn { width: 100%; }
  .ss-form__note { max-width: none; }
  .ss-edu li { grid-template-columns: 1fr; }
  .ss-edu__yr { grid-column: 1; grid-row: auto; margin-top: 2px; }
  .ss-link__k { width: 62px; font-size: 0.64rem; }
  .ss-link__v { font-size: 0.86rem; word-break: break-word; }
}

@media (hover: none) {
  .ss-card { transform: none !important; }
  .ss-card::after { display: none; }
  .ss-btn:hover, .ss-card:hover, .ss-link:hover, .ss-edu li:hover { transform: none; }
  .ss-link:hover, .ss-edu li:hover { padding-left: 2px; }
}

.ss-site .elementor-widget-container { position: relative; }
.ss-site .elementor-widget-container { position: relative; }
.ss-site .elementor-form-fields-wrapper { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.ss-site .elementor-field-group { margin-bottom: 0 !important; }
.ss-site .elementor-field-group-message, .ss-site .elementor-field-type-submit { grid-column: 1 / -1; }
.ss-site .elementor-field-label { display: none; }
.ss-site .elementor-field { width: 100% !important; padding: 22px 14px 10px !important; border: 1px solid rgba(255, 255, 255, 0.08) !important; border-radius: 4px !important; background: rgba(0, 0, 0, 0.28) !important; color: var(--ss-text) !important; font-family: var(--ss-font) !important; font-size: 0.92rem !important; transition: border-color 0.35s, box-shadow 0.35s; }
.ss-site .elementor-field:focus { border-color: rgba(0, 242, 254, 0.55) !important; box-shadow: 0 0 0 3px rgba(0, 242, 254, 0.1) !important; outline: none; }
.ss-site .elementor-field::placeholder { color: #6d7987; }
.ss-site .elementor-button { width: 100%; min-height: 50px; border: 0; border-radius: 999px; background: linear-gradient(100deg, var(--ss-cyan), #6bf7ff 60%, var(--ss-green)) !important; color: #06121a !important; font-weight: 600; letter-spacing: -0.005em; box-shadow: 0 10px 34px -12px rgba(0, 242, 254, 0.65); transition: transform 0.4s var(--ss-ease), box-shadow 0.4s var(--ss-ease); }
.ss-site .elementor-button:hover { transform: translateY(-2px); box-shadow: 0 18px 44px -14px rgba(0, 242, 254, 0.8); }
.ss-site .elementor-message-success { color: var(--ss-green) !important; font-family: var(--ss-mono); font-size: 0.78rem; }
.ss-site .elementor-message-danger { color: #ff6b81 !important; font-family: var(--ss-mono); font-size: 0.78rem; }
.ss-site .elementor-section { background: transparent !important; }
</style>

<div class="ss-site" id="top">

  <div class="ss-progress" aria-hidden="true"></div>

  <header class="ss-nav">
    <a class="ss-brand" href="#top" aria-label="Saad Shamsi, back to top">
      <span class="ss-brand__mark" aria-hidden="true">SS</span>
      Saad Shamsi
      <small>DevSecOps</small>
    </a>

    <nav class="ss-nav__links" aria-label="Sections">
      <a href="#expertise">Expertise</a>
      <a href="#experience">Experience</a>
      <a href="#credentials">Credentials</a>
      <a href="#contact">Contact</a>
    </nav>

    <div class="ss-nav__cta">
      <span class="ss-avail"><i class="ss-dot" aria-hidden="true"></i>Open to new roles</span>
      <a class="ss-btn ss-btn--ghost" href="#contact">Get in touch</a>
      <button class="ss-burger" type="button" aria-expanded="false" aria-controls="ss-menu" aria-label="Open menu">
        <span></span><span></span>
      </button>
    </div>
  </header>

  <nav class="ss-mobile-menu" id="ss-menu" aria-hidden="true" aria-label="Mobile sections">
    <a href="#expertise"><span>01</span>Expertise</a>
    <a href="#experience"><span>02</span>Experience</a>
    <a href="#credentials"><span>03</span>Credentials</a>
    <a href="#contact"><span>04</span>Contact</a>
  </nav>

  <section class="ss-hero">
    <div class="ss-hero__bg" aria-hidden="true"></div>
    <div class="ss-hero__grid" aria-hidden="true"></div>
    <canvas class="ss-particles" aria-hidden="true"></canvas>

    <div class="ss-wrap">
      <div class="ss-hero__grid-c">

        <div class="ss-hero__copy">
          <p class="ss-hero__status" data-hero style="--d:0.25s">
            <i class="ss-dot" aria-hidden="true"></i>
            <span><b>Available</b> for DevSecOps &amp; platform roles</span>
          </p>

          <h1 class="ss-title">
            <span class="ss-line"><span>Bridging DevOps,</span></span>
            <span class="ss-line"><span>Cloud Security</span></span>
            <span class="ss-line"><span><span class="amp">&amp;</span> Strategic Leadership</span></span>
          </h1>

          <p class="ss-hero__sub" data-hero style="--d:0.45s">
            Automating CI/CD pipelines, hardening cloud infrastructure and driving SecOps
            innovation — three years of keeping production boring, in the best way.
          </p>

          <div class="ss-hero__actions" data-hero style="--d:0.55s">
            <a class="ss-btn" href="#experience">
              Explore projects
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h9M8.5 4.5 12 8l-3.5 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
            <a class="ss-btn ss-btn--ghost" href="#" download>
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 2.5v8m0 0L4.8 7.3M8 10.5l3.2-3.2M3 12.5h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              Download résumé
            </a>
          </div>

          <p class="ss-hero__stack" data-hero style="--d:0.65s">
            <span>Jenkins</span><span>Docker</span><span>Kubernetes</span><span>Terraform</span><span>Burp Suite</span><span>Cloudflare</span>
          </p>
        </div>

        <div class="ss-portrait" data-hero style="--d:0.15s" aria-label="DevOps logo panel">
          <div class="ss-logo-card" aria-hidden="true">
            <div class="ss-logo-core">
              <span class="ss-logo-mark">SS</span>
            </div>
            <div class="ss-logo-meta">
              <strong>DevOps</strong>
              <span>CI/CD</span>
            </div>
          </div>
          <i class="ss-portrait__bracket" aria-hidden="true"></i>
          <i class="ss-portrait__bracket" aria-hidden="true"></i>
          <i class="ss-portrait__bracket" aria-hidden="true"></i>
          <i class="ss-portrait__bracket" aria-hidden="true"></i>
        </div>

      </div>
    </div>
  </section>

  <section class="ss-metrics" aria-label="Career metrics">
    <div class="ss-wrap">
      <div class="ss-metrics__grid">
        <div class="ss-metric" data-reveal="fade" style="--d:0ms">
          <div class="ss-metric__val"><span data-count="3" data-suffix="+" data-duration="1500">0</span></div>
          <p class="ss-metric__label">Years across DevOps, IT security and infrastructure</p>
        </div>

        <div class="ss-metric" data-reveal="fade" style="--d:90ms">
          <div class="ss-metric__val"><span data-count="25" data-suffix="%" data-duration="1700">0</span></div>
          <p class="ss-metric__label">Less manual deployment effort after automation</p>
        </div>

        <div class="ss-metric" data-reveal="fade" style="--d:180ms">
          <div class="ss-metric__val"><span data-count="30" data-suffix="+" data-duration="1900">0</span></div>
          <p class="ss-metric__label">Penetration tests and security audits run</p>
        </div>

        <div class="ss-metric" data-reveal="fade" style="--d:270ms">
          <div class="ss-metric__val"><span data-count="99.9" data-decimals="1" data-suffix="%" data-duration="2100">0</span></div>
          <p class="ss-metric__label">Infrastructure parity with near-zero downtime</p>
        </div>
      </div>
    </div>
  </section>

  <section class="ss-section" id="expertise">
    <div class="ss-wrap">
      <div class="ss-section-head">
        <h2 class="ss-h2" data-reveal>Core expertise</h2>
        <p class="ss-lead" data-reveal style="--d:80ms">Three areas of work, one outcome: releases that go quietly and infrastructure that survives contact with production.</p>
      </div>

      <div class="ss-cards">
        <article class="ss-card" data-reveal style="--d:0ms">
          <div class="ss-card__icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none"><path d="M4 7h5l2 3h9M4 17h4l2-3h10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><circle cx="4" cy="7" r="1.6" stroke="currentColor" stroke-width="1.4"/><circle cx="4" cy="17" r="1.6" stroke="currentColor" stroke-width="1.4"/></svg>
          </div>
          <h3 class="ss-card__title">CI/CD &amp; DevOps automation</h3>
          <p class="ss-card__desc">Pipelines built to fail loudly in staging and never in production. Jenkins and Maven work cut deploy time by 30%; Terraform and Ansible keep every environment identical.</p>
          <div class="ss-chips">
            <span class="ss-chip">Jenkins</span><span class="ss-chip">Docker</span><span class="ss-chip">Kubernetes</span><span class="ss-chip">Git</span><span class="ss-chip">GitHub Actions</span><span class="ss-chip">Terraform</span><span class="ss-chip">Ansible</span><span class="ss-chip">Maven</span>
          </div>
        </article>

        <article class="ss-card" data-reveal style="--d:90ms">
          <div class="ss-card__icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none"><path d="M12 3 5 6v6c0 4 3 7.2 7 9 4-1.8 7-5 7-9V6l-7-3Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="m9 12 2.2 2.2L15.5 10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </div>
          <h3 class="ss-card__title">Cybersecurity &amp; DevSecOps</h3>
          <p class="ss-card__desc">Thirty-plus penetration tests across web and network layers, with remediation that still holds once the report is closed. Security pushed left into the SDLC, not bolted on at the gate.</p>
          <div class="ss-chips">
            <span class="ss-chip">Burp Suite</span><span class="ss-chip">SQL-Map</span><span class="ss-chip">XSS / SQLi</span><span class="ss-chip">OS command injection</span><span class="ss-chip">Vulnerability assessment</span><span class="ss-chip">Fortinet</span>
          </div>
        </article>

        <article class="ss-card" data-reveal style="--d:180ms">
          <div class="ss-card__icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none"><path d="M7 18h9.5a3.5 3.5 0 0 0 .3-7A5.5 5.5 0 0 0 6.3 10 4 4 0 0 0 7 18Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M12 12v5m-2-2 2 2 2-2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </div>
          <h3 class="ss-card__title">Cloud &amp; infrastructure</h3>
          <p class="ss-card__desc">VMware estates, Active Directory and Cloudflare edge rules managed as one system — DNS, DDoS protection and reverse proxies tuned for applications that face the internet.</p>
          <div class="ss-chips">
            <span class="ss-chip">VMware ESXi</span><span class="ss-chip">vCenter</span><span class="ss-chip">AWS</span><span class="ss-chip">Azure</span><span class="ss-chip">Cloudflare</span><span class="ss-chip">Active Directory</span><span class="ss-chip">Reverse proxies</span><span class="ss-chip">VPN</span>
          </div>
        </article>
      </div>
    </div>
  </section>

  <section class="ss-section" id="experience">
    <div class="ss-wrap">
      <div class="ss-section-head">
        <h2 class="ss-h2" data-reveal>Career timeline</h2>
        <p class="ss-lead" data-reveal style="--d:80ms">Help desk to infrastructure ownership to strategy — each role handed over something the next one had to keep running.</p>
      </div>

      <div class="ss-timeline">
        <div class="ss-timeline__rail" aria-hidden="true"><div class="ss-timeline__fill"></div></div>

        <article class="ss-job ss-job--now is-open" data-reveal>
          <p class="ss-job__when"><b>2025</b><span>Oct 2025 — now</span></p>
          <div class="ss-job__node" aria-hidden="true"></div>
          <div class="ss-job__body">
            <button class="ss-job__row" type="button" aria-expanded="true" aria-controls="job-1">
              <span>
                <span class="ss-job__role">Developer Operations Strategist</span>
                <span class="ss-job__co">Apexbit <i>— Pakistan</i></span>
              </span>
              <span class="ss-job__sign" aria-hidden="true"></span>
            </button>
            <div class="ss-job__panel" id="job-1" role="region">
              <div>
                <ul class="ss-job__list">
                  <li>Designed CI/CD pipelines across Jenkins, GitLab CI and GitHub Actions, cutting deployment time by 10%.</li>
                  <li>Led infrastructure-as-code adoption with Terraform and Ansible to standardise developer, staging and production environments.</li>
                  <li>Partnered with engineering leadership on the Developer Operations roadmap, tooling strategy and cloud-native practice on AWS and Azure.</li>
                  <li>Embedded DevSecOps principles into the SDLC alongside security, QA and product teams.</li>
                </ul>
                <div class="ss-job__tags">
                  <span class="ss-chip">Terraform</span><span class="ss-chip">Ansible</span><span class="ss-chip">GitHub Actions</span><span class="ss-chip">AWS</span>
                </div>
              </div>
            </div>
          </div>
        </article>

        <article class="ss-job" data-reveal>
          <p class="ss-job__when"><b>2024</b><span>Feb 2024 — Oct 2025</span></p>
          <div class="ss-job__node" aria-hidden="true"></div>
          <div class="ss-job__body">
            <button class="ss-job__row" type="button" aria-expanded="false" aria-controls="job-2">
              <span>
                <span class="ss-job__role">Assistant IT Manager</span>
                <span class="ss-job__co">MobiTising (Pvt) Ltd <i>— Pakistan</i></span>
              </span>
              <span class="ss-job__sign" aria-hidden="true"></span>
            </button>
            <div class="ss-job__panel" id="job-2" role="region">
              <div>
                <ul class="ss-job__list">
                  <li>Owned end-to-end server operations — issue triage, root cause analysis, resolution — holding near-zero downtime on production systems.</li>
                  <li>Architected Jenkins and Maven pipelines that improved deployment speed by 30%, with automated testing gates to cut release errors.</li>
                  <li>Scripted backup, recovery and monitoring in Bash and Python, removing 25% of manual operational effort and locking in environment parity.</li>
                  <li>Streamlined incident response with development, QA and security, reducing MTTR on critical systems.</li>
                </ul>
                <div class="ss-job__tags">
                  <span class="ss-chip">Jenkins</span><span class="ss-chip">Bash</span><span class="ss-chip">Python</span><span class="ss-chip">Incident response</span>
                </div>
              </div>
            </div>
          </div>
        </article>

        <article class="ss-job" data-reveal>
          <p class="ss-job__when"><b>2022</b><span>Nov 2022 — Feb 2024</span></p>
          <div class="ss-job__node" aria-hidden="true"></div>
          <div class="ss-job__body">
            <button class="ss-job__row" type="button" aria-expanded="false" aria-controls="job-3">
              <span>
                <span class="ss-job__role">Assistant Executive, IT</span>
                <span class="ss-job__co">AIMVIZ (Pvt) Ltd <i>— Pakistan</i></span>
              </span>
              <span class="ss-job__sign" aria-hidden="true"></span>
            </button>
            <div class="ss-job__panel" id="job-3" role="region">
              <div>
                <ul class="ss-job__list">
                  <li>Ran 30+ penetration tests using SQL injection, XSS and OS command injection to clear vulnerabilities before production.</li>
                  <li>Tested web and network surfaces with Burp Suite and SQL-Map, documenting findings and driving remediation with developers.</li>
                  <li>Deployed VMware ESXi and vCenter virtual machines for mail servers and VPN infrastructure supporting call-centre operations.</li>
                  <li>Administered Cloudflare DNS, DDoS protection and reverse proxy rules for internet-facing applications.</li>
                  <li>Provided Tier 2 and 3 support and network troubleshooting for 100+ end users.</li>
                </ul>
                <div class="ss-job__tags">
                  <span class="ss-chip">Burp Suite</span><span class="ss-chip">SQL-Map</span><span class="ss-chip">VMware</span><span class="ss-chip">Cloudflare</span>
                </div>
              </div>
            </div>
          </div>
        </article>

        <article class="ss-job" data-reveal>
          <p class="ss-job__when"><b>2021</b><span>Mar — Dec 2021</span></p>
          <div class="ss-job__node" aria-hidden="true"></div>
          <div class="ss-job__body">
            <button class="ss-job__row" type="button" aria-expanded="false" aria-controls="job-4">
              <span>
                <span class="ss-job__role">Project Intern</span>
                <span class="ss-job__co">Hamdard University <i>— Karachi</i></span>
              </span>
              <span class="ss-job__sign" aria-hidden="true"></span>
            </button>
            <div class="ss-job__panel" id="job-4" role="region">
              <div>
                <ul class="ss-job__list">
                  <li>Built an online complaint management application that automated ticket routing and tracking, shortening student issue resolution.</li>
                  <li>Integrated the tooling into existing business processes with cross-functional teams.</li>
                  <li>Handled system maintenance, updates and troubleshooting to protect uptime through the academic year.</li>
                </ul>
              </div>
            </div>
          </div>
        </article>
      </div>
    </div>
  </section>

  <section class="ss-section" id="credentials">
    <div class="ss-wrap">
      <div class="ss-section-head">
        <h2 class="ss-h2" data-reveal>Education &amp; certification</h2>
        <p class="ss-lead" data-reveal style="--d:80ms">An MBA running alongside the engineering work — the business case for the infrastructure decisions, not just the implementation.</p>
      </div>

      <div class="ss-creds">
        <div data-reveal>
          <h3 class="ss-subhead"><span>Education</span><span>2 programmes</span></h3>
          <ul class="ss-edu">
            <li>
              <span class="ss-edu__deg">Master of Business Administration</span>
              <span class="ss-edu__school">ICMS University, Malaysia</span>
              <span class="ss-edu__yr now">Expected 2027</span>
            </li>
            <li>
              <span class="ss-edu__deg">B.S. Computer Science</span>
              <span class="ss-edu__school">Hamdard University, Karachi</span>
              <span class="ss-edu__yr">2022</span>
            </li>
          </ul>
        </div>

        <div data-reveal style="--d:120ms">
          <h3 class="ss-subhead"><span>Certifications</span><span>6 current</span></h3>
          <ul class="ss-certs">
            <li><b>CCNA Cloud</b><span>Cisco · 2018</span></li>
            <li><b>Fortinet NSE 2</b><span>Network Security · 2022</span></li>
            <li><b>(ISC)² Candidate</b><span>ISC2 · 2023</span></li>
            <li><b>Microsoft Azure Essentials</b><span>Microsoft · 2026</span></li>
            <li><b>Odoo Functional</b><span>Odoo · 2026</span></li>
            <li><b>IBM Cybersecurity</b><span>IBM SkillBuild · 2022</span></li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <section class="ss-section ss-contact" id="contact">
    <div class="ss-wrap">
      <div class="ss-contact__grid">
        <div data-reveal>
          <h2 class="ss-contact__h">Let's talk about your <em>pipeline</em>.</h2>
          <p class="ss-contact__p">Open to DevSecOps, platform engineering and IT infrastructure roles in Malaysia, along with remote-first teams across the region.</p>

          <div class="ss-links">
            <a class="ss-link" href="mailto:saadshamsioffi@gmail.com">
              <span class="ss-link__k">Email</span>
              <span class="ss-link__v">saadshamsioffi@gmail.com</span>
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 12 12 4M6 4h6v6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
            <a class="ss-link" href="https://www.linkedin.com/in/saad-shamsi-3b7439102" target="_blank" rel="noopener noreferrer">
              <span class="ss-link__k">LinkedIn</span>
              <span class="ss-link__v">/in/saad-shamsi-3b7439102</span>
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 12 12 4M6 4h6v6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
            <a class="ss-link" href="https://github.com/MR665420" target="_blank" rel="noopener noreferrer">
              <span class="ss-link__k">GitHub</span>
              <span class="ss-link__v">github.com/MR665420</span>
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 12 12 4M6 4h6v6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
            <a class="ss-link" href="tel:+601151437520">
              <span class="ss-link__k">Phone</span>
              <span class="ss-link__v">+60 11-5143 7520</span>
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 12 12 4M6 4h6v6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
          </div>
        </div>

        <form class="ss-form" data-demo novalidate data-reveal style="--d:120ms">
          <div class="ss-field">
            <input id="cf-name" name="name" type="text" placeholder=" " autocomplete="name" required>
            <label for="cf-name">Your name</label>
          </div>
          <div class="ss-field">
            <input id="cf-email" name="email" type="email" placeholder=" " autocomplete="email" required>
            <label for="cf-email">Email address</label>
          </div>
          <div class="ss-field ss-field--full">
            <input id="cf-subject" name="subject" type="text" placeholder=" ">
            <label for="cf-subject">Role or project</label>
          </div>
          <div class="ss-field ss-field--full">
            <textarea id="cf-message" name="message" rows="4" placeholder=" " required></textarea>
            <label for="cf-message">What are you building?</label>
          </div>
          <div class="ss-form__foot">
            <button class="ss-btn" type="submit">
              Send message
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M2.5 8h10M9 4.5 12.5 8 9 11.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
            <p class="ss-form__note">Straight to my inbox. Usually answered within a day.</p>
          </div>
          <p class="ss-form__msg" role="status">Message sent — thanks, I'll get back to you shortly.</p>
        </form>
      </div>
    </div>
  </section>

  <footer class="ss-footer">
    <div class="ss-wrap">
      <div class="ss-footer__c">
        <span>© 2026 Saad Shamsi. Built and maintained in-house.</span>
        <span>
          <a href="mailto:saadshamsioffi@gmail.com">Email</a>
          &nbsp;·&nbsp;
          <a href="https://www.linkedin.com/in/saad-shamsi-3b7439102" target="_blank" rel="noopener noreferrer">LinkedIn</a>
          &nbsp;·&nbsp;
          <a href="https://github.com/MR665420" target="_blank" rel="noopener noreferrer">GitHub</a>
          &nbsp;·&nbsp;
          <a href="#top">Back to top</a>
        </span>
      </div>
    </div>
  </footer>
</div>

<script>
(function () {
  'use strict';

  var root = document.querySelector('.ss-site');
  if (!root) return;

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  var coarse = window.matchMedia('(hover: none)');
  var isSmall = window.matchMedia('(max-width: 900px)');
  var motionOK = function () { return !reduce.matches; };

  requestAnimationFrame(function () {
    requestAnimationFrame(function () { root.classList.add('is-loaded'); });
  });

  var progress = root.querySelector('.ss-progress');
  var nav = root.querySelector('.ss-nav');
  var rail = root.querySelector('.ss-timeline__fill');
  var timeline = root.querySelector('.ss-timeline');
  var lastScroll = -1;
  var ticking = false;

  function onScrollFrame() {
    ticking = false;
    var y = window.scrollY || window.pageYOffset;
    if (y === lastScroll) return;
    lastScroll = y;

    if (progress) {
      var doc = document.documentElement;
      var max = doc.scrollHeight - window.innerHeight;
      progress.style.transform = 'scaleX(' + (max > 0 ? Math.min(y / max, 1) : 0) + ')';
    }

    if (nav) nav.classList.toggle('is-scrolled', y > 24);

    if (rail && timeline && timeline.getBoundingClientRect) {
      var r = timeline.getBoundingClientRect();
      var vh = window.innerHeight || 800;
      var p = (vh * 0.62 - r.top) / r.height;
      rail.style.transform = 'scaleY(' + Math.max(0, Math.min(1, p)) + ')';
    }
  }

  function requestScrollFrame() {
    if (!ticking) { ticking = true; requestAnimationFrame(onScrollFrame); }
  }

  window.addEventListener('scroll', requestScrollFrame, { passive: true });
  window.addEventListener('resize', requestScrollFrame, { passive: true });
  onScrollFrame();

  var revealables = Array.prototype.slice.call(root.querySelectorAll('[data-reveal]'));

  if ('IntersectionObserver' in window && motionOK()) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        el.classList.add('is-in');
        io.unobserve(el);
        el.querySelectorAll('[data-count]').forEach(runCounter);
        if (el.hasAttribute('data-count')) runCounter(el);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.12 });

    revealables.forEach(function (el) { io.observe(el); });
  } else {
    revealables.forEach(function (el) { el.classList.add('is-in'); });
    root.querySelectorAll('[data-count]').forEach(setFinal);
  }

  function setFinal(el) {
    var to = parseFloat(el.getAttribute('data-count')) || 0;
    var dec = parseInt(el.getAttribute('data-decimals') || '0', 10);
    el.textContent = to.toFixed(dec) + (el.getAttribute('data-suffix') || '');
  }

  function runCounter(el) {
    if (el.dataset.counted === '1') return;
    el.dataset.counted = '1';

    var raw = el.getAttribute('data-count');
    var to = parseFloat(raw) || 0;
    var dec = parseInt(el.getAttribute('data-decimals') || '0', 10);
    var suffix = el.getAttribute('data-suffix') || '';
    var dur = parseInt(el.getAttribute('data-duration') || '1900', 10);

    if (!motionOK() || dur < 100) { setFinal(el); return; }

    var start = null;
    var ease = function (t) { return t === 1 ? 1 : 1 - Math.pow(2, -10 * t); };

    function step(ts) {
      if (start === null) start = ts;
      var t = Math.min((ts - start) / dur, 1);
      var v = to * ease(t);
      el.textContent = v.toFixed(dec) + suffix;
      if (t < 1) requestAnimationFrame(step);
      else el.textContent = to.toFixed(dec) + suffix;
    }
    requestAnimationFrame(step);
  }

  var cards = Array.prototype.slice.call(root.querySelectorAll('.ss-card'));
  cards.forEach(function (card) {
    card.addEventListener('pointermove', function (e) {
      var r = card.getBoundingClientRect();
      var px = (e.clientX - r.left) / r.width;
      var py = (e.clientY - r.top) / r.height;
      card.style.setProperty('--mx', (px * 100).toFixed(2) + '%');
      card.style.setProperty('--my', (py * 100).toFixed(2) + '%');

      if (reduce.matches || coarse.matches) return;
      card.style.setProperty('--ry', ((px - 0.5) * 9).toFixed(2) + 'deg');
      card.style.setProperty('--rx', ((0.5 - py) * 7).toFixed(2) + 'deg');
    });

    card.addEventListener('pointerleave', function () {
      card.style.setProperty('--rx', '0deg');
      card.style.setProperty('--ry', '0deg');
    });
  });

  root.querySelectorAll('.ss-job').forEach(function (job) {
    var btn = job.querySelector('.ss-job__row');
    if (!btn) return;

    btn.addEventListener('click', function () {
      var open = job.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');

      if (open && isSmall.matches) {
        root.querySelectorAll('.ss-job.is-open').forEach(function (other) {
          if (other === job) return;
          other.classList.remove('is-open');
          var ob = other.querySelector('.ss-job__row');
          if (ob) ob.setAttribute('aria-expanded', 'false');
        });
      }
    });
  });

  var burger = root.querySelector('.ss-burger');
  var menu = root.querySelector('.ss-mobile-menu');

  if (burger && menu) {
    var setMenu = function (open) {
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      menu.classList.toggle('is-open', open);
      menu.setAttribute('aria-hidden', open ? 'false' : 'true');
      document.documentElement.style.overflow = open ? 'hidden' : '';
    };

    burger.addEventListener('click', function () {
      setMenu(burger.getAttribute('aria-expanded') !== 'true');
    });

    menu.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { setMenu(false); });
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') setMenu(false);
    });
  }

  root.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var id = a.getAttribute('href');
      if (!id || id === '#') return;
      var target = document.querySelector(id);
      if (!target) return;

      e.preventDefault();
      var offset = (nav ? nav.offsetHeight : 0) + 12;
      var top = target.getBoundingClientRect().top + window.pageYOffset - offset;
      window.scrollTo({ top: top, behavior: motionOK() ? 'smooth' : 'auto' });
    });
  });

  var form = root.querySelector('.ss-form');
  if (form && form.hasAttribute('data-demo')) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      form.classList.add('is-sent');
      form.reset();
      setTimeout(function () { form.classList.remove('is-sent'); }, 6000);
    });
  }

  var canvas = root.querySelector('.ss-particles');
  if (!canvas || !canvas.getContext || !motionOK()) {
    if (canvas) canvas.style.display = 'none';
    return;
  }

  var ctx = canvas.getContext('2d');
  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var w = 0, h = 0, raf = null, visible = true, dots = [];

  function size() {
    var rect = canvas.parentElement.getBoundingClientRect();
    w = rect.width;
    h = rect.height;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    var count = Math.round((w * h) / 26000);
    count = Math.max(18, Math.min(count, isSmall.matches ? 26 : 64));

    dots = [];
    for (var i = 0; i < count; i++) {
      dots.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.16,
        vy: (Math.random() - 0.5) * 0.16,
        r: Math.random() * 1.4 + 0.5,
        a: Math.random() * 0.42 + 0.14,
        g: Math.random() > 0.82
      });
    }
  }

  var LINK = 118;
  function draw() {
    raf = null;
    if (!visible) return;

    ctx.clearRect(0, 0, w, h);

    for (var i = 0; i < dots.length; i++) {
      var d = dots[i];
      d.x += d.vx;
      d.y += d.vy;

      if (d.x < -12) d.x = w + 12; else if (d.x > w + 12) d.x = -12;
      if (d.y < -12) d.y = h + 12; else if (d.y > h + 12) d.y = -12;

      for (var j = i + 1; j < dots.length; j++) {
        var o = dots[j];
        var dx = d.x - o.x, dy = d.y - o.y;
        var dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > LINK) continue;
        var alpha = (1 - dist / LINK) * 0.16;
        ctx.strokeStyle = 'rgba(0,242,254,' + alpha.toFixed(3) + ')';
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(o.x, o.y);
        ctx.stroke();
      }

      ctx.beginPath();
      ctx.fillStyle = d.g ? 'rgba(0,255,136,' + d.a.toFixed(2) + ')' : 'rgba(0,242,254,' + d.a.toFixed(2) + ')';
      ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
      ctx.fill();
    }

    raf = requestAnimationFrame(draw);
  }

  function start() {
    if (!raf && visible) raf = requestAnimationFrame(draw);
  }
  function stop() {
    if (raf) { cancelAnimationFrame(raf); raf = null; }
  }

  size();
  start();

  var rz;
  window.addEventListener('resize', function () {
    clearTimeout(rz);
    rz = setTimeout(function () { size(); start(); }, 220);
  }, { passive: true });

  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      visible = entries[0].isIntersecting;
      if (visible) start(); else stop();
    }, { threshold: 0 }).observe(canvas);
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) stop(); else start();
  });
})();
</script>
<?php
get_footer();
