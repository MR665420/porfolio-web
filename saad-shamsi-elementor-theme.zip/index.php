<?php
/**
 * Main template file for the Saad Shamsi portfolio theme.
 */

if (is_front_page()) {
    get_header();
    include get_template_directory() . '/front-page.php';
    get_footer();
    return;
}

get_header();
?>
<main class="ss-site ss-site--fallback">
    <div class="ss-wrap" style="padding-top: 120px; padding-bottom: 80px;">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h1><?php the_title(); ?></h1>
                    <?php the_content(); ?>
                </article>
            <?php endwhile; ?>
        <?php else : ?>
            <h1>Nothing found</h1>
            <p>This theme is set up for the portfolio homepage.</p>
        <?php endif; ?>
    </div>
</main>
<?php
get_footer();
