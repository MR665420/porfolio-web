<?php

function saad_shamsi_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    add_theme_support('editor-styles');
    add_theme_support('align-wide');
}
add_action('after_setup_theme', 'saad_shamsi_theme_setup');

function saad_shamsi_enqueue_assets() {
    wp_enqueue_style('saad-shamsi-theme', get_stylesheet_uri(), array(), '1.0.0');
}
add_action('wp_enqueue_scripts', 'saad_shamsi_enqueue_assets');

function saad_shamsi_elementor_support() {
    if (class_exists('Elementor\\Plugin')) {
        add_theme_support('elementor');
    }
}
add_action('after_setup_theme', 'saad_shamsi_elementor_support');
